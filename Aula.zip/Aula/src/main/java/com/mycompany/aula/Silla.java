/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula;

/**
 *
 * @author leona
 */
class Silla extends Mobiliario {
    private int numeroPatas;

    public Silla(String tipo, String color, String material, int numeroPatas) {
        super(tipo, color, material);
        this.numeroPatas = numeroPatas;
    }

    public int obtenerNumeroPatas() {
        return numeroPatas;
    }
}

