/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula;

/**
 *
 * @author leona
 */
class Mobiliario {
    private String tipo;
    private String color;
    private String material;

    public Mobiliario(String tipo, String color, String material) {
        this.tipo = tipo;
        this.color = color;
        this.material = material;
    }

    public String obtenerTipo() {
        return tipo;
    }

    public String obtenerColor() {
        return color;
    }

    public String obtenerMaterial() {
        return material;
    }
}