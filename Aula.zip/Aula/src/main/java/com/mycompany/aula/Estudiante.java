/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula;

/**
 *
 * @author leona
 */
class Estudiante extends Persona {

    private String nivel;

    public Estudiante(String nombre, int edad, String nivel) {
        super(nombre, edad);
        this.nivel = nivel;
    }

    public String obtenerNivel() {
        return nivel;
    }
}
