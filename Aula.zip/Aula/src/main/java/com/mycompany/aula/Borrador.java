/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula;

/**
 *
 * @author leona
 */
class Borrador extends Utensilio {

    private String tamano;

    public Borrador(String nombre, String material, String tamano) {
        super(nombre, material);
        this.tamano = tamano;
    }

    public String obtenerTamano() {
        return tamano;
    }
}
