/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula;

/**
 *
 * @author leona
 */
class Pizarra extends Utensilio {

    private String color;

    public Pizarra(String nombre, String material, String color) {
        super(nombre, material);
        this.color = color;
    }

    public String obtenerColor() {
        return color;
    }
}
