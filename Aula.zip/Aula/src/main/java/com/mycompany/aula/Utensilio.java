/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula;

/**
 *
 * @author leona
 */
class Utensilio {
    private String nombre;
    private String material;

    public Utensilio(String nombre, String material) {
        this.nombre = nombre;
        this.material = material;
    }

    public String obtenerNombre() {
        return nombre;
    }

    public String obtenerMaterial() {
        return material;
    }
}

