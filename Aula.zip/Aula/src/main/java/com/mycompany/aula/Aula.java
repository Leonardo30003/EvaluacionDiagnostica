/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.aula;

import java.util.Scanner;

/**
 *
 * @author leona
 */
public class Aula {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("¿Qué clase desea instanciar?");
        System.out.println("1. Silla");
        System.out.println("2. Mesa");
        System.out.println("3. Proyector");
        System.out.println("4. Computadora");
        System.out.println("5. Pizarra");
        System.out.println("6. Borrador");
        System.out.println("7. Profesor");
        System.out.println("8. Estudiante");

        int opcion = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea después del número

        switch (opcion) {
            case 1:
                crearSilla(scanner);
                break;
            case 2:
                crearMesa(scanner);
                break;
            case 3:
                crearProyector(scanner);
                break;
            case 4:
                crearComputadora(scanner);
                break;
            case 5:
                crearPizarra(scanner);
                break;
            case 6:
                crearBorrador(scanner);
                break;
            case 7:
                crearProfesor(scanner);
                break;
            case 8:
                crearEstudiante(scanner);
                break;
            default:
                System.out.println("Opción inválida");
                break;
        }

        scanner.close();
    }

    public static void crearSilla(Scanner scanner) {
        System.out.println("\nIngrese los datos de la silla:");
        System.out.print("Tipo: ");
        String tipoSilla = scanner.nextLine();
        System.out.print("Color: ");
        String colorSilla = scanner.nextLine();
        System.out.print("Material: ");
        String materialSilla = scanner.nextLine();
        System.out.print("Número de patas: ");
        int numeroPatasSilla = scanner.nextInt();
        scanner.nextLine();

        Silla silla = new Silla(tipoSilla, colorSilla, materialSilla, numeroPatasSilla);

        System.out.println("\nInformación de la silla:");
        System.out.println("Tipo: " + silla.obtenerTipo());
        System.out.println("Color: " + silla.obtenerColor());
        System.out.println("Material: " + silla.obtenerMaterial());
        System.out.println("Número de patas: " + silla.obtenerNumeroPatas());
    }

    public static void crearMesa(Scanner scanner) {
        System.out.println("\nIngrese los datos de la mesa:");
        System.out.print("Tipo: ");
        String tipoMesa = scanner.nextLine();
        System.out.print("Color: ");
        String colorMesa = scanner.nextLine();
        System.out.print("Material: ");
        String materialMesa = scanner.nextLine();
        System.out.print("Número de patas: ");
        int numeroPatasMesa = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Tamaño: ");
        String tamanoMesa = scanner.nextLine();

        Mesa mesa = new Mesa(tipoMesa, colorMesa, materialMesa, numeroPatasMesa, tamanoMesa);

        System.out.println("\nInformación de la mesa:");
        System.out.println("Tipo: " + mesa.obtenerTipo());
        System.out.println("Color: " + mesa.obtenerColor());
        System.out.println("Material: " + mesa.obtenerMaterial());
        System.out.println("Número de patas: " + mesa.obtenerNumeroPatas());
        System.out.println("Tamaño: " + mesa.obtenerTamano());
    }

    private static void crearProyector(Scanner scanner) {
        System.out.println("\nIngrese los datos del proyector:");
        System.out.print("Marca: ");
        String marcaProyector = scanner.nextLine();
        System.out.print("Modelo: ");
        String modeloProyector = scanner.nextLine();
        System.out.print("Precio: ");
        double precioProyector = scanner.nextDouble();
        System.out.print("Resolución: ");
        int resolucionProyector = scanner.nextInt();
        scanner.nextLine();

        Proyector proyector = new Proyector(marcaProyector, modeloProyector, precioProyector, resolucionProyector);

        System.out.println("\nInformación del proyector:");
        System.out.println("Marca: " + proyector.obtenerMarca());
        System.out.println("Modelo: " + proyector.obtenerModelo());
        System.out.println("Precio: " + proyector.obtenerPrecio());
        System.out.println("Resolución: " + proyector.obtenerResolucion());

    }

    private static void crearComputadora(Scanner scanner) {
        System.out.println("\nIngrese los datos de la computadora:");
        System.out.print("Marca: ");
        String marcaComputadora = scanner.nextLine();
        System.out.print("Modelo: ");
        String modeloComputadora = scanner.nextLine();
        System.out.print("Precio: ");
        double precioComputadora = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Sistema operativo: ");
        String sistemaOperativoComputadora = scanner.nextLine();
        System.out.print("Capacidad de memoria: ");
        int capacidadMemoriaComputadora = scanner.nextInt();
        scanner.nextLine();

        Computadora computadora = new Computadora(marcaComputadora, modeloComputadora, precioComputadora,
                sistemaOperativoComputadora, capacidadMemoriaComputadora);

        System.out.println("\nInformación de la computadora:");
        System.out.println("Marca: " + computadora.obtenerMarca());
        System.out.println("Modelo: " + computadora.obtenerModelo());
        System.out.println("Precio: " + computadora.obtenerPrecio());
        System.out.println("Sistema operativo: " + computadora.obtenerSistemaOperativo());
        System.out.println("Capacidad de memoria: " + computadora.obtenerCapacidadMemoria());
    }

    private static void crearPizarra(Scanner scanner) {
        System.out.println("\nIngrese los datos de la pizarra:");
        System.out.print("Nombre: ");
        String nombrePizarra = scanner.nextLine();
        System.out.print("Material: ");
        String materialPizarra = scanner.nextLine();
        System.out.print("Color: ");
        String colorPizarra = scanner.nextLine();

        Pizarra pizarra = new Pizarra(nombrePizarra, materialPizarra, colorPizarra);

        System.out.println("\nInformación de la pizarra:");
        System.out.println("Nombre: " + pizarra.obtenerNombre());
        System.out.println("Material: " + pizarra.obtenerMaterial());
        System.out.println("Color: " + pizarra.obtenerColor());
    }

    private static void crearBorrador(Scanner scanner) {
        System.out.println("\nIngrese los datos del borrador:");
        System.out.print("Nombre: ");
        String nombreBorrador = scanner.nextLine();
        System.out.print("Material: ");
        String materialBorrador = scanner.nextLine();
        System.out.print("Tamaño: ");
        String tamañoBorrador = scanner.nextLine();

        Borrador borrador = new Borrador(nombreBorrador, materialBorrador, tamañoBorrador);

        System.out.println("\nInformación del borrador:");
        System.out.println("Nombre: " + borrador.obtenerNombre());
        System.out.println("Material: " + borrador.obtenerMaterial());
        System.out.println("Tamaño: " + borrador.obtenerTamano());

    }

    private static void crearProfesor(Scanner scanner) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static void crearEstudiante(Scanner scanner) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
