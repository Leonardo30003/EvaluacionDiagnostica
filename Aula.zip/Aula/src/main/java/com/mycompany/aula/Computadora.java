/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula;

/**
 *
 * @author leona
 */
class Computadora extends EquipoElectronico {
    private String sistemaOperativo;
    private int capacidadMemoria;

    public Computadora(String marca, String modelo, double precio, String sistemaOperativo, int capacidadMemoria) {
        super(marca, modelo, precio);
        this.sistemaOperativo = sistemaOperativo;
        this.capacidadMemoria = capacidadMemoria;
    }

    public String obtenerSistemaOperativo() {
        return sistemaOperativo;
    }

    public int obtenerCapacidadMemoria() {
        return capacidadMemoria;
    }
}
