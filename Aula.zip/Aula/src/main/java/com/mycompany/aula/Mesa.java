/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula;

/**
 *
 * @author leona
 */
class Mesa extends Mobiliario {
    private int numeroPatas;
    private String tamano;

    public Mesa(String tipo, String color, String material, int numeroPatas, String tamano) {
        super(tipo, color, material);
        this.numeroPatas = numeroPatas;
        this.tamano = tamano;
    }

    public int obtenerNumeroPatas() {
        return numeroPatas;
    }

    public String obtenerTamano() {
        return tamano;
    }
}
