/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula;

/**
 *
 * @author leona
 */
class Proyector extends EquipoElectronico {
    private int resolucion;

    public Proyector(String marca, String modelo, double precio, int resolucion) {
        super(marca, modelo, precio);
        this.resolucion = resolucion;
    }

    public int obtenerResolucion() {
        return resolucion;
    }
}
